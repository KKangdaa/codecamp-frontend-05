export default function ProductUI(props) {

  return (
    <div>
      <h1>{props.isEdit ? "수정" : "등록"}페이지</h1>
      판매자: <input type="text" /><br />
      상품명: <input type="text" /><br />
      내용: <input type="text" /><br />
      가격: <input type="text" /><br />
      <button onClick={props.isEdit ? props.updateButton : props.createButton }>{props.isEdit ? "수정" : "등록"}하기</button>
    </div>
  )
}