import ProductDetail from '../../../src/components/units/product/detail/container'

export default function EditPage(){
  return <ProductDetail />
}