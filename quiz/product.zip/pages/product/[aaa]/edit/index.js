import ProductWrite from "../../../../src/components/units/product/write/container";

export default function ProductEdit() {
  return(
    <ProductWrite isEdit={true} />
  ) 
}