import ProductWrite from '../../../src/components/units/product/write/container'

export default function ProductNew() {

  return(
    <ProductWrite isEdit={false} />
  )
}